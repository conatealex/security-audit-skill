-- =====================================================================
-- AGENDA DE ATENDIMENTO — Gabriela Sousa
-- Banco: Supabase (projeto ynslnzlkykvocayesftr), schema public.
-- Pré-aplicado no projeto; este arquivo serve de documentação e para
-- replicar em outro banco (rode na ordem).
-- =====================================================================
--
-- SEGURANÇA (o motivo de tudo parecer "complicado"):
--  * RLS ligado em TODAS as tabelas e nenhuma policy: o papel `anon`
--    (chave pública do navegador) NÃO lê nem escreve nada direto.
--  * Toda leitura e escrita passa por funções SECURITY DEFINER, que
--    validam tudo dentro do banco.
--  * A trava `ag_sem_sobreposicao` impede dois clientes no mesmo
--    horário — a proteção é no banco, não no JavaScript.
--  * O painel não guarda token: só o SHA-256 dele, conferido por função.
-- =====================================================================

-- ------------------------------ TABELAS ------------------------------
create table if not exists public.ag_faixas (
  id bigint generated always as identity primary key,
  dia smallint not null check (dia between 0 and 6),   -- 0=domingo … 6=sábado
  inicio time not null,
  fim time not null,
  ativo boolean not null default true,
  check (fim > inicio)
);

create table if not exists public.ag_config (
  chave text primary key,
  valor jsonb not null
);

create table if not exists public.ag_bloqueios (
  id bigint generated always as identity primary key,
  data date not null,
  inicio time,               -- null = dia inteiro
  fim time,
  motivo text,
  check (fim is null or inicio is not null)
);

create table if not exists public.ag_reservas (
  codigo uuid primary key default gen_random_uuid(),
  inicio timestamptz not null,
  fim timestamptz not null,
  nome text not null check (char_length(btrim(nome)) between 2 and 120),
  telefone text not null check (telefone ~ '^[0-9]{10,15}$'),
  motivo text check (motivo is null or char_length(motivo) <= 400),
  status text not null default 'pendente'
    check (status in ('pendente','confirmada','cancelada','concluida')),
  criado_em timestamptz not null default now(),
  atualizado_em timestamptz not null default now()
);

-- Trava de banco: pendente ou confirmada disputam o mesmo intervalo
alter table public.ag_reservas drop constraint if exists ag_sem_sobreposicao;
alter table public.ag_reservas add constraint ag_sem_sobreposicao
  exclude using gist (tstzrange(inicio, fim) WITH &&)
  where (status in ('pendente', 'confirmada'));

create index if not exists ag_reservas_inicio_idx on public.ag_reservas (inicio desc);
create index if not exists ag_reservas_status_idx on public.ag_reservas (status, inicio);

create table if not exists public.ag_admin_tokens (
  hash text primary key,      -- SHA-256 do token, nunca o token
  rotulo text not null default 'profissional',
  ativo boolean not null default true,
  criado_em timestamptz not null default now()
);

alter table public.ag_faixas enable row level security;
alter table public.ag_config enable row level security;
alter table public.ag_bloqueios enable row level security;
alter table public.ag_reservas enable row level security;
alter table public.ag_admin_tokens enable row level security;

revoke all on public.ag_faixas from anon, authenticated;
revoke all on public.ag_config from anon, authenticated;
revoke all on public.ag_bloqueios from anon, authenticated;
revoke all on public.ag_reservas from anon, authenticated;
revoke all on public.ag_admin_tokens from anon, authenticated;

-- ------------------------------- SEEDS -------------------------------
insert into public.ag_config (chave, valor) values
  ('sessao_min', '50'),
  ('intervalo_min', '60'),
  ('antecedencia_min', '120'),
  ('dias_a_frente', '90')
on conflict (chave) do nothing;

-- De segunda a segunda (fim de semana reduzido)
insert into public.ag_faixas (dia, inicio, fim, ativo)
select d.dia::smallint, d.inicio::time, d.fim::time, true
from (values
  (1,'09:00','12:00'), (1,'14:00','18:00'),
  (2,'09:00','12:00'), (2,'14:00','18:00'),
  (3,'09:00','12:00'), (3,'14:00','18:00'),
  (4,'09:00','12:00'), (4,'14:00','18:00'),
  (5,'09:00','12:00'), (5,'14:00','18:00'),
  (6,'09:00','12:00'),
  (0,'09:00','12:00')
) as d(dia, inicio, fim)
where not exists (select 1 from public.ag_faixas);

-- Token atual do painel (apenas o hash)
insert into public.ag_admin_tokens (hash, rotulo)
values ('e0781712bcc0ac679eebf60a4c3647b803e595f599029cbc74c2b2e9d5a81e14', 'Gabriela')
on conflict (hash) do nothing;

-- Para TROCAR o token do painel (gere um novo e publique o link):
--   1) gere:  echo -n "SEU-NOVO-TOKEN" | sha256sum
--   2) rode:  insert into ag_admin_tokens (hash, rotulo) values ('<hash-novo>', 'Gabriela');
--   3) rode:  update ag_admin_tokens set ativo = false where hash <> '<hash-novo>';

-- ------------------------------ FUNÇÕES ------------------------------
-- ag__cfg(chave)            -> lê uma regra geral (minutos)
-- ag__hoje()                -> data de hoje no fuso America/Sao_Paulo
-- ag__slots_dia(data)       -> grade de horários daquele dia
-- ag_info()                 -> configuração + grade (pública)
-- ag_slots_disponiveis(de,ate) -> dias e horários livres (público)
-- ag_criar_reserva(inicio,nome,fone,motivo) -> registra PENDENTE (público)
-- ag_meus_compromissos(fone) -> compromissos do próprio cliente (público)
-- ag_status_reserva(codigo)  -> status pelo código do pedido (público)
-- ag_admin_listar(hash)      -> lista de pedidos (só com hash certo)
-- ag_admin_decidir(hash,codigo,acao) -> confirmar/cancelar/concluir

-- (Corpo completo destas funções está aplicado no projeto; rode este
--  arquivo de cima para baixo num banco novo e use as migrações
--  `ag_tabelas`, `ag_funcoes_v3`, `ag_fix_slots_e_fuso` como referência —
--  elas aparecem no histórico de migrações do painel do Supabase.)

grant execute on function public.ag_info() to anon, authenticated;
grant execute on function public.ag_slots_disponiveis(date, date) to anon, authenticated;
grant execute on function public.ag_criar_reserva(timestamptz, text, text, text) to anon, authenticated;
grant execute on function public.ag_meus_compromissos(text) to anon, authenticated;
grant execute on function public.ag_status_reserva(uuid) to anon, authenticated;
grant execute on function public.ag_admin_listar(text) to anon, authenticated;
grant execute on function public.ag_admin_decidir(text, uuid, text) to anon, authenticated;

revoke execute on function public.ag__cfg(text) from public, anon, authenticated;
revoke execute on function public.ag__hoje() from public, anon, authenticated;
revoke execute on function public.ag__slots_dia(date) from public, anon, authenticated;
