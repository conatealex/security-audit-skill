// =====================================================================
// Envia o código de confirmação da troca de senha da Gabriela.
//
// Ordem de tentativa:
//   1. WhatsApp oficial (Meta Cloud API), se as variáveis existirem;
//   2. e-mail (Resend ou Brevo), se as variáveis existirem;
//   3. se nada estiver configurado, devolve o código e o link pronto do
//      WhatsApp (wa.me) para o painel mostrar o botão "Enviar pelo WhatsApp".
//
// Variáveis de ambiente (Netlify → Site settings → Environment variables):
//   WHATSAPP_TOKEN        token permanente da Meta (WhatsApp Cloud API)
//   WHATSAPP_PHONE_ID     id do número de envio
//   WHATSAPP_PARA         destino (padrão 5543996754869)
//   WHATSAPP_TEMPLATE     nome do modelo aprovado (opcional; sem ele só dá
//                         para responder dentro da janela de 24h)
//   RESEND_API_KEY        alternativa por e-mail
//   BREVO_API_KEY         alternativa por e-mail
//   EMAIL_REMETENTE / EMAIL_DESTINO
// =====================================================================

const SUPABASE_URL = 'https://ynslnzlkykvocayesftr.supabase.co';
const SUPABASE_ANON =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inluc2xuemxreWt2b2NheWVzZnRyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTI1MTU3MDEsImV4cCI6MjEwODA5MTcwMX0.BE5rfbtpGgtakoeGA_OZUg80wtwa1Yb_sm_1r1Omovs';

const ZAP_PADRAO = '5543996754869';

const json = (status, corpo) =>
  new Response(JSON.stringify(corpo), {
    status,
    headers: { 'content-type': 'application/json', 'cache-control': 'no-store' },
  });

const escapar = (t) =>
  String(t).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function mensagemZap({ codigo, tipo, minutos }) {
  const acao = tipo === 'recuperacao' ? 'recuperar o acesso à sua agenda' : 'confirmar a troca da sua senha';
  return (
    `*Agenda Gabriela Sousa*\n\n` +
    `Você pediu para ${acao}.\n\n` +
    `Código de confirmação: *${codigo}*\n\n` +
    `Vale por ${minutos} minutos e só pode ser usado uma vez. ` +
    `Se não foi você, ignore esta mensagem: nada muda na sua agenda.`
  );
}

function linkZap(para, texto) {
  return `https://wa.me/${para}?text=${encodeURIComponent(texto)}`;
}

function corpoEmail({ codigo, tipo, minutos }) {
  const titulo = tipo === 'recuperacao' ? 'Recuperar o acesso à agenda' : 'Confirmar a troca da sua senha';
  const explicacao =
    tipo === 'recuperacao'
      ? 'Pedimos um novo link de acesso para a sua agenda. Para liberá-lo, use o código abaixo.'
      : 'Pedimos a troca do link de acesso da sua agenda. Para confirmar, use o código abaixo.';

  const texto =
    `${titulo}\n\n${explicacao}\n\nCódigo: ${codigo}\n\n` +
    `Ele vale por ${minutos} minutos e só pode ser usado uma vez.\n\n` +
    `Se não foi você quem pediu, ignore esta mensagem: nada muda na sua agenda.\n\n` +
    `Gabriela Sousa · Neuropsicologia · CRP 08/308-27\n`;

  const html = `<!doctype html><html lang="pt-BR"><body style="margin:0;background:#F6EDE7;padding:24px;font-family:Arial,Helvetica,sans-serif;color:#333">
  <div style="max-width:520px;margin:0 auto;background:#fff;border-radius:16px;overflow:hidden;border:1px solid #E9DAD2">
    <div style="background:#740829;color:#fff;padding:20px 24px">
      <div style="font-size:12px;letter-spacing:.14em;text-transform:uppercase;color:#EFC3A4">Agenda · Gabriela Sousa</div>
      <div style="font-size:20px;font-weight:700;margin-top:6px">${escapar(titulo)}</div>
    </div>
    <div style="padding:24px">
      <p style="margin:0 0 16px;font-size:15px;line-height:1.6">${escapar(explicacao)}</p>
      <div style="text-align:center;margin:22px 0">
        <div style="display:inline-block;padding:14px 26px;border-radius:12px;background:#F6EDE7;border:1px dashed #B87A52;
                    font-size:30px;letter-spacing:.35em;font-weight:700;color:#740829">${escapar(codigo)}</div>
      </div>
      <p style="margin:0 0 8px;font-size:14px;line-height:1.6">Vale por <strong>${minutos} minutos</strong> e só pode ser usado uma vez.</p>
      <p style="margin:0;font-size:14px;line-height:1.6;color:#5F5A57">Se não foi você quem pediu, ignore esta mensagem: nada muda na sua agenda.</p>
    </div>
    <div style="padding:16px 24px;background:#FCFCFC;border-top:1px solid #E9DAD2;font-size:12px;color:#777">
      Gabriela Sousa · Neuropsicologia · CRP 08/308-27<br>
      Elaborado por Alexsandro R Sousa (Alex Sosua) @contatealex
    </div>
  </div>
</body></html>`;

  return { titulo, texto, html };
}

async function enviarWhatsAppMeta({ para, texto }) {
  const token = process.env.WHATSAPP_TOKEN;
  const phoneId = process.env.WHATSAPP_PHONE_ID;
  const template = process.env.WHATSAPP_TEMPLATE;
  const versao = process.env.META_GRAPH_VERSION || 'v25.0';
  if (!token || !phoneId) return { tentou: false };

  const url = `https://graph.facebook.com/${versao}/${phoneId}/messages`;
  const corpo = template
    ? {
        messaging_product: 'whatsapp',
        to: para,
        type: 'template',
        template: {
          name: template,
          language: { code: process.env.WHATSAPP_TEMPLATE_LANG || 'pt_BR' },
          components: [{ type: 'body', parameters: [{ type: 'text', text: texto }] }],
        },
      }
    : { messaging_product: 'whatsapp', to: para, type: 'text', text: { body: texto } };

  const r = await fetch(url, {
    method: 'POST',
    headers: { authorization: `Bearer ${token}`, 'content-type': 'application/json' },
    body: JSON.stringify(corpo),
  });
  if (!r.ok) {
    const detalhe = await r.text();
    return { tentou: true, ok: false, mensagem: 'WhatsApp recusou: ' + detalhe.slice(0, 200) };
  }
  return { tentou: true, ok: true };
}

async function enviarEmail({ titulo, texto, html, destino }) {
  const remetente = process.env.EMAIL_REMETENTE || 'Agenda Gabriela <onboarding@resend.dev>';

  if (process.env.RESEND_API_KEY) {
    const r = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { authorization: `Bearer ${process.env.RESEND_API_KEY}`, 'content-type': 'application/json' },
      body: JSON.stringify({ from: remetente, to: [destino], subject: titulo, text: texto, html }),
    });
    if (!r.ok) return { tentou: true, ok: false, mensagem: 'Resend: ' + (await r.text()).slice(0, 160) };
    return { tentou: true, ok: true, provedor: 'resend' };
  }
  if (process.env.BREVO_API_KEY) {
    const r = await fetch('https://api.brevo.com/v3/smtp/email', {
      method: 'POST',
      headers: { 'api-key': process.env.BREVO_API_KEY, 'content-type': 'application/json' },
      body: JSON.stringify({
        sender: { email: (remetente.match(/<(.+)>/) || [, remetente])[1], name: 'Agenda Gabriela' },
        to: [{ email: destino }],
        subject: titulo,
        textContent: texto,
        htmlContent: html,
      }),
    });
    if (!r.ok) return { tentou: true, ok: false, mensagem: 'Brevo: ' + (await r.text()).slice(0, 160) };
    return { tentou: true, ok: true, provedor: 'brevo' };
  }
  return { tentou: false };
}

export default async (request) => {
  if (request.method !== 'POST') return json(405, { enviado: false, mensagem: 'Use POST.' });

  let corpo;
  try {
    corpo = await request.json();
  } catch {
    return json(400, { enviado: false, mensagem: 'Corpo inválido.' });
  }

  const id = corpo && corpo.id;
  if (!id || !/^[0-9a-f-]{36}$/i.test(id)) return json(400, { enviado: false, mensagem: 'Pedido inválido.' });

  // 1) O banco confirma que o pedido existe e devolve o código
  let pendente;
  try {
    const r = await fetch(`${SUPABASE_URL}/rest/v1/rpc/ag_email_pendente`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', apikey: SUPABASE_ANON },
      body: JSON.stringify({ p_id: id }),
    });
    if (!r.ok) return json(400, { enviado: false, mensagem: 'Pedido não reconhecido.' });
    pendente = await r.json();
  } catch {
    return json(502, { enviado: false, mensagem: 'Sem conexão com a agenda.' });
  }

  if (!pendente || !pendente.codigo) {
    return json(404, { enviado: false, mensagem: 'Pedido expirado. Faça de novo.' });
  }

  const para = (process.env.WHATSAPP_PARA || ZAP_PADRAO).replace(/\D/g, '');
  const destinoEmail = process.env.EMAIL_DESTINO || 'psicologagabrielasousa@gmail.com';
  const textoZap = mensagemZap({ codigo: pendente.codigo, tipo: pendente.tipo, minutos: 30 });
  const email = corpoEmail({ codigo: pendente.codigo, tipo: pendente.tipo, minutos: 30 });

  const zapLink = linkZap(para, textoZap);
  const resposta = { codigo: pendente.codigo, para, zapLink, canais: {} };

  // 2) WhatsApp oficial (se configurado)
  try {
    const zap = await enviarWhatsAppMeta({ para, texto: textoZap });
    resposta.canais.whatsapp = zap;
    if (zap.tentou && zap.ok) {
      return json(200, { ...resposta, enviado: true, canal: 'whatsapp' });
    }
  } catch (e) {
    resposta.canais.whatsapp = { tentou: true, ok: false, mensagem: String(e && e.message).slice(0, 120) };
  }

  // 3) E-mail (se configurado)
  try {
    const mail = await enviarEmail({ titulo: `${email.titulo} — código ${pendente.codigo}`, texto: email.texto, html: email.html, destino: destinoEmail });
    resposta.canais.email = mail;
    if (mail.tentou && mail.ok) {
      return json(200, { ...resposta, enviado: true, canal: 'email' });
    }
  } catch (e) {
    resposta.canais.email = { tentou: true, ok: false, mensagem: String(e && e.message).slice(0, 120) };
  }

  // 4) Nada configurado: devolve o código e o link do WhatsApp para o painel
  return json(200, {
    ...resposta,
    enviado: false,
    mensagem:
      'Nenhum envio automático está configurado. Use o botão do WhatsApp abaixo: a mensagem já vai pronta com o código.',
  });
};
