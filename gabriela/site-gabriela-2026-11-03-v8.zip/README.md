# Site + Agenda de atendimento — Gabriela Sousa

Pasta pronta para publicar no **Netlify** (site estático, sem build, sem servidor).

| Arquivo | O que é |
|---|---|
| `index.html` | Site institucional (com as fotos novas, a seção **Espaço** e o botão **Agendar Horário** abrindo a agenda em nova aba) |
| `agenda.html` | **App de agendamento**: calendário de segunda a segunda, horários livres, formulário e consulta de compromissos |
| `admin.html` | **Painel da Gabriela**: lista os pedidos e confirma / cancela / conclui |
| `netlify.toml` | Cabeçalhos de segurança (CSP fechada nas duas páginas do app, sem cache no painel) e cache longo para `assets/` |
| `assets/` | Fotos e imagens do site (hero, sobre, consultório, símbolo do infinito e monograma) |
| `db/schema.sql` | Documentação do banco aplicado no Supabase |


## Fotos e imagens (atualização 02/11/2026)

As fotos da Gabriela agora são **arquivos separados** em `assets/` — não ficam mais
embutidas em base64 dentro do `index.html` (o arquivo caiu de ~780 KB para ~51 KB).

| Arquivo | Onde aparece | Formato |
|---|---|---|
| `assets/gabriela-hero.webp` / `.png` | Foto principal do topo (busto recortado, com contorno branco suave e transparência) | WebP 900 px (fallback PNG) |
| `assets/gabriela-sobre.jpg` | Foto da seção **Sobre** (retrato 3:4, fundo de estúdio claro) | JPEG 760 × 1013 |
| `assets/consultorio-gabriela.jpg` / `.webp` | Seção **Espaço** (foto sentada no consultório) | JPEG/WebP 1280 × 960 |
| `assets/simbolo-infinito.png` | Símbolo do infinito com peças de quebra-cabeça — fundo animado do topo | PNG com transparência, 512 × 512 |
| `assets/logo-gabriela.png` | Monograma GS do cabeçalho e do rodapé | PNG com transparência |

Todas as fotos vieram do material enviado pela Gabriela. O recorte do topo foi feito
sem gerar imagem nova: o fundo de parede do estúdio foi removido, e a silhueta recebeu
um contorno branco suave para destacar a foto sobre o bordô.

### Ajuste de cor do topo

O bordô do topo foi suavizado para o símbolo do infinito voltar a aparecer:

- fundo em degradê radial `#8B2450 → #6A1638 → #4A0D25` (antes era chapado em `#740829`);
- símbolo a **58%** de opacidade e 420 px (antes 42% e 460 px);
- véu de leitura mais leve: `rgba(60,11,32,.84) → .58 → .18` à esquerda/direita
  (antes `.95 → .86 → .55`), mantendo o texto branco legível.


### Topo (hero) — foto maior e fundo em 3D

- A foto passou a **preencher toda a coluna direita** (recorte 858 × 1084 px, proporção
  0,79 — quase a mesma do espaço), com 700 px de largura máxima e sangria suave no rodapé.
- O fundo tem **duas camadas do símbolo** andando em velocidades diferentes
  (620 px desfocada a 70 s + 360 px nítida a 34 s): é a diferença de velocidade que
  cria a sensação de profundidade. Some a isso um ponto de luz fixo (`.hero-glow`).
- O símbolo agora tem **sombra projetada, brilho superior e contorno claro** (efeito
  "extrudado" 3D) — feito em `assets/simbolo-infinito.png`, sem depender de JS.
- No celular a camada desfocada é desligada (economia de bateria) e a foto fica com
  a largura toda da tela.

## Publicar

1. Acesse [app.netlify.com/drop](https://app.netlify.com/drop).
2. Arraste **esta pasta inteira**.
3. Pronto: o Netlify entrega `index.html` na raiz e aplica os cabeçalhos do `netlify.toml`.

Depois é só apontar o domínio no painel do Netlify (Site settings → Domain management).

## Acesso ao painel (admin.html)

O painel é protegido por um **link secreto**. Ele NÃO está nesta pasta de propósito:

- Quem tiver o link entra na agenda completa; guarde como senha.
- O endereço tem a forma `SEU-DOMINIO.netlify.app/admin.html#SEUTOKEN`.
- O navegador transforma o token em hash (SHA-256) na hora e **só o hash viaja**;
  o banco confere o hash e responde. Sem o token certo: "Acesso não autorizado".
- Para trocar o token, rode o bloco "trocar token" em `db/schema.sql`.

## Como funciona o fluxo

1. O cliente escolhe dia e horário em `agenda.html` e envia os dados.
2. A reserva é gravada como **pendente** — e uma trava no banco impede que duas
   pessoas levem o mesmo horário (mesmo abrindo a página em duas abas ao mesmo tempo).
3. O cliente clica em "Enviar pedido no WhatsApp" e a mensagem chega pronta
   (dia, hora e código do pedido).
4. A Gabriela confirma no painel → status muda para **confirmado**.
5. "Consultar meus compromissos" mostra o status pelo telefone do cliente.

## Ajustar horários e regras

Tudo está no Supabase (projeto `ynslnzlkykvocayesftr`), nas tabelas `ag_*`:

```sql
-- Fechar o domingo
update ag_faixas set ativo = false where dia = 0;

-- Atendimento de tarde só às quartas
delete from ag_faixas where dia = 3 and inicio = '14:00';

-- Bloquear um feriado (dia inteiro)
insert into ag_bloqueios (data, motivo) values ('2026-12-25', 'Natal');

-- Bloquear um horário pontual
insert into ag_bloqueios (data, inicio, fim, motivo) values ('2026-11-15', '14:00', '18:00', 'Compromisso');

-- Regras gerais (minutos)
update ag_config set valor = '45' where chave = 'sessao_min';      -- duração da sessão
update ag_config set valor = '60' where chave = 'intervalo_min';   -- intervalo entre atendimentos
update ag_config set valor = '180' where chave = 'antecedencia_min'; -- antecedência mínima
update ag_config set valor = '120' where chave = 'dias_a_frente';  -- dias de horizonte
```

Os dados dos clientes só ficam visíveis para o painel (token) e para o próprio
cliente (telefone + código do pedido). Nenhum segredo está nos arquivos HTML:
a chave que aparece nele é a chave **pública** (anon) do Supabase, e o RLS do
banco decide o que ela pode — que é só: ler a grade e criar pedidos.

## Menu rápido radial (v3, 02/11/2026)

No canto inferior direito da home há um botão flutuante em vinho escuro
(`#4A0E17`), posicionado a `96px` do rodapé para não ficar embaixo do selo
"Powered by Netlify". Ao clicar, ele abre um **espaço branco em destaque**
(disco com aro cobre sobre um véu vinho leve) e revela cinco atalhos em leque:

| Atalho | Destino | Ícone |
| --- | --- | --- |
| Agendar | `agenda.html` (nova aba) | calendário |
| Serviços | `#servicos` | lista |
| Atendimento | `#atendimento` | usuário |
| Valores | `#valores` | etiqueta |
| Contato | `#contato` | mensagem |

Detalhes de implementação (sem bibliotecas):

- as abas ficam em `position: absolute` no centro do botão e a posição radial
  vem das variáveis CSS `--ang` (ângulo) e `--i` (ordem da animação);
- a abertura usa `transform: rotate(var(--ang)) translateY(-r) rotate(...)`,
  com atraso escalonado `calc(var(--i) * 40ms + 40ms)`;
- o "morphing" é o par `.quick__disc` (disco branco que escala de 0,12 para 1)
  + `.quick__core` (raio 50% → 34%, ícone `+` → `×`);
- tamanhos: botão `clamp(66px, 8.6vw, 78px)`, abas `clamp(52px, 6vw, 66px)`,
  ícones `clamp(24px, 2.7vw, 30px)` e raio do leque `clamp(158px, 18vw, 196px)`;
- acessibilidade: `aria-expanded`, `aria-controls`, `aria-label`, abas com
  `tabindex="-1"` quando fechadas, `Esc` fecha e devolve o foco, e
  `prefers-reduced-motion` desliga as animações.

O botão do WhatsApp fica à esquerda (`bottom: 84px`), acima do "voltar ao topo".

## Acesso ao painel pelo site

Três portas de entrada para a Gabriela confirmar horários:

1. seção "Agenda" da home: botão **"É a Gabriela? Confirmar horários"**;
2. rodapé da home: **"Área da Gabriela — confirmar horários"**;
3. rodapé da agenda: **"É a Gabriela? Abrir o painel de confirmações"**.

Todas levam a `admin.html`, que pede o token (link com `#TOKEN` ou token
colado no campo). Com **"Manter conectada neste aparelho por 30 dias"** marcado,
o painel guarda só o *hash* em `localStorage` e passa a abrir direto nas
próximas visitas; o botão "Sair" apaga esse registro.

O token **nunca** deve ser gravado neste repositório (ele é público). Os tokens
ficam em `ag_admin_tokens` apenas como hash SHA-256.

> Atenção: até a v2 o `admin.html` estava com `supabaseAnonKey` vazio, e por
> isso o painel respondia 401 e não abria. A v3 preenche a chave pública
> (a mesma do `agenda.html`, que só permite ler a grade e criar pedidos).

## Revisão de texto (v4, 02/11/2026)

- **Título do topo**: "Compreender a pessoa para além dos sintomas e diagnósticos"
  (mesma diagramação, com a segunda parte em itálico como antes).
- **Formação**: saíram "Análise do Comportamento Aplicada (ABA)" e
  "Neurociência, Psicopatologia e Comportamento (ARTMED, em curso)". Entraram
  "Transtorno do Espectro Autista no Contexto Clínico" (Uniopet, 2024),
  "Transtorno Opositivo Desafiador" (Uniopet, 2025) e "Reabilitação
  Neuropsicológica" (Hospital Israelita Albert Einstein). O parágrafo de
  apresentação foi ajustado para não citar a formação em curso.
- **Ortografia e fluidez**: "pra mim" → "para mim"; "Presencial em Apucarana e
  online" → "Presencial e online" (Apucarana já aparece no cabeçalho, no
  rodapé e na seção de atendimento).
- **Travessões removidos de todo o texto visível** (vírgula, dois-pontos,
  ponto médio `·` ou reescrita da frase). O CSS ficou intacto: os traços que
  aparecem como marcadores de lista continuam sendo desenhados pelo
  `content: '—'`, que não é texto do site.

### Ajustes finais (v5)

- Travessões também saíram das páginas `agenda.html` e `admin.html`.
- O campo "motivo" do pedido passou a usar dois-pontos em vez de travessão
  (`Psicoterapia: primeira conversa`), então a lista do painel fica limpa.

## Login do painel à prova de erro (v6)

O campo de acesso ficou tolerante ao que a pessoa cola:

- aceita o **link inteiro** (`...admin.html#CODIGO`), o link com `?t=`, só o
  código, o código **em grupos de 4** (`abcd-ef01-...`) ou com espaços e
  quebras de linha (como vem do WhatsApp);
- ignora aspas, parênteses e caracteres invisíveis; tenta maiúsculas e
  minúsculas;
- botão **"Colar o link"** (lê a área de transferência e já entra);
- botão **"Mostrar o código"** para conferir o que foi colado;
- mensagens de erro traduzidas: página desatualizada (401), código errado e
  falta de conexão.

## Painel v7 (02/11/2026): jornada, reservas, relatório e senha

O painel agora tem quatro abas.

### 1. Pedidos
Igual antes: confirmar, cancelar, concluir e WhatsApp do cliente.

### 2. Minha jornada
- **Domingo a domingo**, um interruptor por dia: marcado = atende, desmarcado = fechado.
- Cada dia aceita até **3 períodos** (ex.: 09:00–12:00 e 14:00–18:00), com botão para
  acrescentar ou remover.
- "Salvar jornada" grava em `ag_faixas` via `ag_admin_grade_salvar`; o que fica
  desmarcado simplesmente desaparece da agenda do paciente.
- **Reservar (bloquear)**: escolhe uma data e, opcionalmente, o horário
  (das/até). Sem horário, reserva o dia inteiro. Grava em `ag_bloqueios`
  (`ag_admin_bloquear` / `ag_admin_bloquear_horario`). A lista mostra o que
  está reservado e o botão **Liberar** devolve o horário à agenda
  (`ag_admin_desbloquear_id`).

Os dois caminhos são respeitados pelo lado público: `ag_slots_disponiveis` e
`ag_criar_reserva` já descartam qualquer horário que caia em jornada fechada OU
em bloqueio, de dia inteiro ou parcial.

### 3. Relatório
- Semana de **segunda a domingo**, com navegação para a semana anterior e a seguinte.
- Tabela com data, hora, paciente, WhatsApp, motivo e situação, agrupada por dia,
  mais os totais (confirmados, pendentes, realizados).
- **Imprimir ou salvar em PDF** usa `window.print()` com folha de estilo de
  impressão (`@page A4`, cabeçalho com o nome da clínica, cores preservadas).
  O rodapé do PDF sai com o crédito do responsável técnico.

### 4. Minha senha
- **Gerar novo link de acesso**: cria um pedido em `ag_trocas_senha` e dispara um
  e-mail com **código de 6 caracteres** (validade de 30 minutos, uso único).
  A troca só acontece quando o código é confirmado (`ag_confirmar_troca`);
  o link antigo é desativado no mesmo instante.
- **Esqueci a senha** (na tela de entrada) segue o mesmo caminho, mas gera um
  link novo sem exigir o antigo.
- O hash SHA-256 da senha antiga nunca volta para o navegador: o banco guarda
  só hashes, e o código de confirmação é o que autoriza a troca.

#### Envio do e-mail (função do Netlify)
`netlify/functions/enviar-codigo.mjs` monta a mensagem e envia por **Resend** ou
**Brevo**. Configure no Netlify (Site settings → Environment variables):

| Variável | Exemplo |
| --- | --- |
| `RESEND_API_KEY` | `re_...` (recomendado; precisa de remetente verificado) |
| `BREVO_API_KEY` | alternativa |
| `EMAIL_REMETENTE` | `Agenda Gabriela <agenda@seudominio.com.br>` |
| `EMAIL_DESTINO` | padrão `psicologagabrielasousa@gmail.com` |

Sem essas variáveis o painel avisa que o e-mail ainda não está configurado e o
pedido fica pendente no banco (nada é trocado sem a confirmação).

### Sessão
"Manter a agenda aberta neste aparelho" passou a não ter prazo: a sessão fica
até clicar em **Sair**. O botão está sempre no topo da aba de pedidos.

### Crédito no rodapé
As três páginas (`index.html`, `agenda.html`, `admin.html`) mostram
"Elaborado por Alexsandro R Sousa (Alex Sosua) @contatealex", e o relatório
impresso também.

## Ajustes v8 (02/11/2026)

### 1. Código de confirmação por WhatsApp
- O painel agora tenta, nesta ordem: **WhatsApp oficial (Meta Cloud API)** →
  **e-mail (Resend/Brevo)** → **botão do WhatsApp com a mensagem pronta**.
- Quando nenhum envio automático está configurado, a tela mostra o **código**,
  um botão **"Enviar o código pelo WhatsApp"** (link `wa.me` para
  `5543996754869`, já com o texto e o código dentro) e o botão copiar.
- Variáveis para envio automático no Netlify:

| Variável | Para que serve |
| --- | --- |
| `WHATSAPP_TOKEN` | token permanente da Meta (Cloud API) |
| `WHATSAPP_PHONE_ID` | id do número que envia |
| `WHATSAPP_PARA` | destino (padrão `5543996754869`) |
| `WHATSAPP_TEMPLATE` | nome do modelo aprovado (opcional) |
| `WHATSAPP_TEMPLATE_LANG` | idioma do modelo (padrão `pt_BR`) |
| `RESEND_API_KEY` / `BREVO_API_KEY` | alternativa por e-mail |

### 2. Nada abre em aba nova
Todos os links internos (`agenda.html`, `admin.html`, âncoras) abrem na mesma
aba, tanto para a Gabriela quanto para o cliente. Só links externos (WhatsApp,
Instagram) continuam em aba nova, porque saem do site.

### 3. Animação do topo mais rápida e reluzente
- Símbolo da frente: varredura de **34 s → 11 s**.
- Camada de trás: **70 s → 22 s**.
- Novo efeito **`hero-brilho`** (3,1 s): o símbolo acende forte (brilho branco +
  cobre, `brightness(1.45)`, `saturate(1.35)`) e enfraquece de volta, em ciclo.
- O halo do topo (`hero-glow`) pulsa no mesmo compasso.
- `prefers-reduced-motion` continua desligando tudo.
