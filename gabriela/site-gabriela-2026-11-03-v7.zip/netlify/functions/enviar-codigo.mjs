// =====================================================================
// Envia o código de confirmação da troca de senha da Gabriela.
//
// Por que existe: a troca do link de acesso só vale depois que a
// profissional confirma um código que chega no e-mail dela. Esta função
// só monta e envia esse e-mail — quem aprova é o banco (ag_confirmar_troca).
//
// Variáveis de ambiente (Netlify → Site settings → Environment variables):
//   RESEND_API_KEY   (recomendado) chave da Resend, domínio ou remetente verificado
//   BREVO_API_KEY    (alternativa) chave da Brevo
//   EMAIL_REMETENTE  ex.: "Agenda Gabriela <agenda@seudominio.com.br>"
//   EMAIL_DESTINO    padrão: psicologagabrielasousa@gmail.com
// =====================================================================

const SUPABASE_URL = 'https://ynslnzlkykvocayesftr.supabase.co';
const SUPABASE_ANON =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inluc2xuemxreWt2b2NheWVzZnRyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTI1MTU3MDEsImV4cCI6MjEwODA5MTcwMX0.BE5rfbtpGgtakoeGA_OZUg80wtwa1Yb_sm_1r1Omovs';

const json = (status, corpo) =>
  new Response(JSON.stringify(corpo), {
    status,
    headers: { 'content-type': 'application/json', 'cache-control': 'no-store' },
  });

const escapar = (t) =>
  String(t).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function corpoEmail({ codigo, tipo, minutos }) {
  const titulo = tipo === 'recuperacao' ? 'Recuperar o acesso à agenda' : 'Confirmar a troca da sua senha';
  const explicacao =
    tipo === 'recuperacao'
      ? 'Pedimos um novo link de acesso para a sua agenda. Para liberá-lo, use o código abaixo.'
      : 'Pedimos a troca do link de acesso da sua agenda. Para confirmar, use o código abaixo.';

  const texto =
    `${titulo}\n\n${explicacao}\n\nCódigo: ${codigo}\n\n` +
    `Ele vale por ${minutos} minutos e só pode ser usado uma vez.\n\n` +
    `Se não foi você quem pediu, ignore este e-mail: nada muda na sua agenda.\n\n` +
    `Gabriela Sousa · Neuropsicologia · CRP 08/308-27\n`;

  const html = `<!doctype html><html lang="pt-BR"><body style="margin:0;background:#F6EDE7;padding:24px;font-family:Arial,Helvetica,sans-serif;color:#333">
  <div style="max-width:520px;margin:0 auto;background:#fff;border-radius:16px;overflow:hidden;border:1px solid #E9DAD2">
    <div style="background:#740829;color:#fff;padding:20px 24px">
      <div style="font-size:12px;letter-spacing:.14em;text-transform:uppercase;color:#EFC3A4">Agenda · Gabriela Sousa</div>
      <div style="font-size:20px;font-weight:700;margin-top:6px">${escapar(titulo)}</div>
    </div>
    <div style="padding:24px">
      <p style="margin:0 0 16px;font-size:15px;line-height:1.6">${escapar(explicacao)}</p>
      <div style="text-align:center;margin:22px 0">
        <div style="display:inline-block;padding:14px 26px;border-radius:12px;background:#F6EDE7;border:1px dashed #B87A52;
                    font-size:30px;letter-spacing:.35em;font-weight:700;color:#740829">${escapar(codigo)}</div>
      </div>
      <p style="margin:0 0 8px;font-size:14px;line-height:1.6">Vale por <strong>${minutos} minutos</strong> e só pode ser usado uma vez.</p>
      <p style="margin:0;font-size:14px;line-height:1.6;color:#5F5A57">Se não foi você quem pediu, ignore este e-mail: nada muda na sua agenda.</p>
    </div>
    <div style="padding:16px 24px;background:#FCFCFC;border-top:1px solid #E9DAD2;font-size:12px;color:#777">
      Gabriela Sousa · Neuropsicologia · CRP 08/308-27<br>
      Elaborado por Alexsandro R Sousa (Alex Sosua) @contatealex
    </div>
  </div>
</body></html>`;

  return { titulo, texto, html };
}

export default async (request) => {
  if (request.method !== 'POST') return json(405, { enviado: false, mensagem: 'Use POST.' });

  let corpo;
  try {
    corpo = await request.json();
  } catch {
    return json(400, { enviado: false, mensagem: 'Corpo inválido.' });
  }

  const id = corpo && corpo.id;
  if (!id || !/^[0-9a-f-]{36}$/i.test(id)) return json(400, { enviado: false, mensagem: 'Pedido inválido.' });

  // 1) O banco confirma que existe um pedido válido e devolve o código
  let pendente;
  try {
    const r = await fetch(`${SUPABASE_URL}/rest/v1/rpc/ag_email_pendente`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', apikey: SUPABASE_ANON },
      body: JSON.stringify({ p_id: id }),
    });
    if (!r.ok) return json(400, { enviado: false, mensagem: 'Pedido não reconhecido.' });
    pendente = await r.json();
  } catch {
    return json(502, { enviado: false, mensagem: 'Sem conexão com a agenda.' });
  }

  if (!pendente || !pendente.codigo) {
    return json(404, { enviado: false, mensagem: 'Pedido expirado. Faça de novo.' });
  }

  const destino = process.env.EMAIL_DESTINO || 'psicologagabrielasousa@gmail.com';
  const remetente = process.env.EMAIL_REMETENTE || 'Agenda Gabriela <onboarding@resend.dev>';
  const conteudo = corpoEmail({ codigo: pendente.codigo, tipo: pendente.tipo, minutos: 30 });

  // 2) Envia pelo provedor configurado
  try {
    if (process.env.RESEND_API_KEY) {
      const r = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          authorization: `Bearer ${process.env.RESEND_API_KEY}`,
          'content-type': 'application/json',
        },
        body: JSON.stringify({
          from: remetente,
          to: [destino],
          subject: `${conteudo.titulo} — código ${pendente.codigo}`,
          text: conteudo.texto,
          html: conteudo.html,
        }),
      });
      if (!r.ok) {
        const erro = await r.text();
        return json(502, { enviado: false, mensagem: 'A Resend recusou o envio: ' + erro.slice(0, 180) });
      }
      return json(200, { enviado: true, para: destino, provedor: 'resend' });
    }

    if (process.env.BREVO_API_KEY) {
      const r = await fetch('https://api.brevo.com/v3/smtp/email', {
        method: 'POST',
        headers: {
          'api-key': process.env.BREVO_API_KEY,
          'content-type': 'application/json',
        },
        body: JSON.stringify({
          sender: { email: (remetente.match(/<(.+)>/) || [, remetente])[1], name: 'Agenda Gabriela' },
          to: [{ email: destino }],
          subject: `${conteudo.titulo} — código ${pendente.codigo}`,
          textContent: conteudo.texto,
          htmlContent: conteudo.html,
        }),
      });
      if (!r.ok) {
        const erro = await r.text();
        return json(502, { enviado: false, mensagem: 'A Brevo recusou o envio: ' + erro.slice(0, 180) });
      }
      return json(200, { enviado: true, para: destino, provedor: 'brevo' });
    }

    return json(200, {
      enviado: false,
      mensagem:
        'E-mail ainda não configurado. Defina RESEND_API_KEY (ou BREVO_API_KEY) e EMAIL_REMETENTE nas variáveis de ambiente do Netlify.',
    });
  } catch (e) {
    return json(502, { enviado: false, mensagem: 'Falha ao enviar: ' + String(e && e.message).slice(0, 120) });
  }
};
