# Site + Agenda de atendimento — Gabriela Sousa

Pasta pronta para publicar no **Netlify** (site estático, sem build, sem servidor).

| Arquivo | O que é |
|---|---|
| `index.html` | Site institucional (com as fotos novas, a seção **Espaço** e o botão **Agendar Horário** abrindo a agenda em nova aba) |
| `agenda.html` | **App de agendamento**: calendário de segunda a segunda, horários livres, formulário e consulta de compromissos |
| `admin.html` | **Painel da Gabriela**: lista os pedidos e confirma / cancela / conclui |
| `netlify.toml` | Cabeçalhos de segurança (CSP fechada nas duas páginas do app, sem cache no painel) e cache longo para `assets/` |
| `assets/` | Fotos e imagens do site (hero, sobre, consultório, símbolo do infinito e monograma) |
| `db/schema.sql` | Documentação do banco aplicado no Supabase |


## Fotos e imagens (atualização 02/11/2026)

As fotos da Gabriela agora são **arquivos separados** em `assets/` — não ficam mais
embutidas em base64 dentro do `index.html` (o arquivo caiu de ~780 KB para ~51 KB).

| Arquivo | Onde aparece | Formato |
|---|---|---|
| `assets/gabriela-hero.webp` / `.png` | Foto principal do topo (busto recortado, com contorno branco suave e transparência) | WebP 900 px (fallback PNG) |
| `assets/gabriela-sobre.jpg` | Foto da seção **Sobre** (retrato 3:4, fundo de estúdio claro) | JPEG 760 × 1013 |
| `assets/consultorio-gabriela.jpg` / `.webp` | Seção **Espaço** (foto sentada no consultório) | JPEG/WebP 1280 × 960 |
| `assets/simbolo-infinito.png` | Símbolo do infinito com peças de quebra-cabeça — fundo animado do topo | PNG com transparência, 512 × 512 |
| `assets/logo-gabriela.png` | Monograma GS do cabeçalho e do rodapé | PNG com transparência |

Todas as fotos vieram do material enviado pela Gabriela. O recorte do topo foi feito
sem gerar imagem nova: o fundo de parede do estúdio foi removido, e a silhueta recebeu
um contorno branco suave para destacar a foto sobre o bordô.

### Ajuste de cor do topo

O bordô do topo foi suavizado para o símbolo do infinito voltar a aparecer:

- fundo em degradê radial `#8B2450 → #6A1638 → #4A0D25` (antes era chapado em `#740829`);
- símbolo a **58%** de opacidade e 420 px (antes 42% e 460 px);
- véu de leitura mais leve: `rgba(60,11,32,.84) → .58 → .18` à esquerda/direita
  (antes `.95 → .86 → .55`), mantendo o texto branco legível.


### Topo (hero) — foto maior e fundo em 3D

- A foto passou a **preencher toda a coluna direita** (recorte 858 × 1084 px, proporção
  0,79 — quase a mesma do espaço), com 700 px de largura máxima e sangria suave no rodapé.
- O fundo tem **duas camadas do símbolo** andando em velocidades diferentes
  (620 px desfocada a 70 s + 360 px nítida a 34 s): é a diferença de velocidade que
  cria a sensação de profundidade. Some a isso um ponto de luz fixo (`.hero-glow`).
- O símbolo agora tem **sombra projetada, brilho superior e contorno claro** (efeito
  "extrudado" 3D) — feito em `assets/simbolo-infinito.png`, sem depender de JS.
- No celular a camada desfocada é desligada (economia de bateria) e a foto fica com
  a largura toda da tela.

## Publicar

1. Acesse [app.netlify.com/drop](https://app.netlify.com/drop).
2. Arraste **esta pasta inteira**.
3. Pronto: o Netlify entrega `index.html` na raiz e aplica os cabeçalhos do `netlify.toml`.

Depois é só apontar o domínio no painel do Netlify (Site settings → Domain management).

## Acesso ao painel (admin.html)

O painel é protegido por um **link secreto**. Ele NÃO está nesta pasta de propósito:

- Quem tiver o link entra na agenda completa; guarde como senha.
- O endereço tem a forma `SEU-DOMINIO.netlify.app/admin.html#SEUTOKEN`.
- O navegador transforma o token em hash (SHA-256) na hora e **só o hash viaja**;
  o banco confere o hash e responde. Sem o token certo: "Acesso não autorizado".
- Para trocar o token, rode o bloco "trocar token" em `db/schema.sql`.

## Como funciona o fluxo

1. O cliente escolhe dia e horário em `agenda.html` e envia os dados.
2. A reserva é gravada como **pendente** — e uma trava no banco impede que duas
   pessoas levem o mesmo horário (mesmo abrindo a página em duas abas ao mesmo tempo).
3. O cliente clica em "Enviar pedido no WhatsApp" e a mensagem chega pronta
   (dia, hora e código do pedido).
4. A Gabriela confirma no painel → status muda para **confirmado**.
5. "Consultar meus compromissos" mostra o status pelo telefone do cliente.

## Ajustar horários e regras

Tudo está no Supabase (projeto `ynslnzlkykvocayesftr`), nas tabelas `ag_*`:

```sql
-- Fechar o domingo
update ag_faixas set ativo = false where dia = 0;

-- Atendimento de tarde só às quartas
delete from ag_faixas where dia = 3 and inicio = '14:00';

-- Bloquear um feriado (dia inteiro)
insert into ag_bloqueios (data, motivo) values ('2026-12-25', 'Natal');

-- Bloquear um horário pontual
insert into ag_bloqueios (data, inicio, fim, motivo) values ('2026-11-15', '14:00', '18:00', 'Compromisso');

-- Regras gerais (minutos)
update ag_config set valor = '45' where chave = 'sessao_min';      -- duração da sessão
update ag_config set valor = '60' where chave = 'intervalo_min';   -- intervalo entre atendimentos
update ag_config set valor = '180' where chave = 'antecedencia_min'; -- antecedência mínima
update ag_config set valor = '120' where chave = 'dias_a_frente';  -- dias de horizonte
```

Os dados dos clientes só ficam visíveis para o painel (token) e para o próprio
cliente (telefone + código do pedido). Nenhum segredo está nos arquivos HTML:
a chave que aparece nele é a chave **pública** (anon) do Supabase, e o RLS do
banco decide o que ela pode — que é só: ler a grade e criar pedidos.

## Menu rápido radial (v3, 02/11/2026)

No canto inferior direito da home há um botão flutuante em vinho escuro
(`#4A0E17`), posicionado a `96px` do rodapé para não ficar embaixo do selo
"Powered by Netlify". Ao clicar, ele abre um **espaço branco em destaque**
(disco com aro cobre sobre um véu vinho leve) e revela cinco atalhos em leque:

| Atalho | Destino | Ícone |
| --- | --- | --- |
| Agendar | `agenda.html` (nova aba) | calendário |
| Serviços | `#servicos` | lista |
| Atendimento | `#atendimento` | usuário |
| Valores | `#valores` | etiqueta |
| Contato | `#contato` | mensagem |

Detalhes de implementação (sem bibliotecas):

- as abas ficam em `position: absolute` no centro do botão e a posição radial
  vem das variáveis CSS `--ang` (ângulo) e `--i` (ordem da animação);
- a abertura usa `transform: rotate(var(--ang)) translateY(-r) rotate(...)`,
  com atraso escalonado `calc(var(--i) * 40ms + 40ms)`;
- o "morphing" é o par `.quick__disc` (disco branco que escala de 0,12 para 1)
  + `.quick__core` (raio 50% → 34%, ícone `+` → `×`);
- tamanhos: botão `clamp(66px, 8.6vw, 78px)`, abas `clamp(52px, 6vw, 66px)`,
  ícones `clamp(24px, 2.7vw, 30px)` e raio do leque `clamp(158px, 18vw, 196px)`;
- acessibilidade: `aria-expanded`, `aria-controls`, `aria-label`, abas com
  `tabindex="-1"` quando fechadas, `Esc` fecha e devolve o foco, e
  `prefers-reduced-motion` desliga as animações.

O botão do WhatsApp fica à esquerda (`bottom: 84px`), acima do "voltar ao topo".

## Acesso ao painel pelo site

Três portas de entrada para a Gabriela confirmar horários:

1. seção "Agenda" da home: botão **"É a Gabriela? Confirmar horários"**;
2. rodapé da home: **"Área da Gabriela — confirmar horários"**;
3. rodapé da agenda: **"É a Gabriela? Abrir o painel de confirmações"**.

Todas levam a `admin.html`, que pede o token (link com `#TOKEN` ou token
colado no campo). Com **"Manter conectada neste aparelho por 30 dias"** marcado,
o painel guarda só o *hash* em `localStorage` e passa a abrir direto nas
próximas visitas; o botão "Sair" apaga esse registro.

O token **nunca** deve ser gravado neste repositório (ele é público). Os tokens
ficam em `ag_admin_tokens` apenas como hash SHA-256.

> Atenção: até a v2 o `admin.html` estava com `supabaseAnonKey` vazio, e por
> isso o painel respondia 401 e não abria. A v3 preenche a chave pública
> (a mesma do `agenda.html`, que só permite ler a grade e criar pedidos).

## Revisão de texto (v4, 02/11/2026)

- **Título do topo**: "Compreender a pessoa para além dos sintomas e diagnósticos"
  (mesma diagramação, com a segunda parte em itálico como antes).
- **Formação**: saíram "Análise do Comportamento Aplicada (ABA)" e
  "Neurociência, Psicopatologia e Comportamento (ARTMED, em curso)". Entraram
  "Transtorno do Espectro Autista no Contexto Clínico" (Uniopet, 2024),
  "Transtorno Opositivo Desafiador" (Uniopet, 2025) e "Reabilitação
  Neuropsicológica" (Hospital Israelita Albert Einstein). O parágrafo de
  apresentação foi ajustado para não citar a formação em curso.
- **Ortografia e fluidez**: "pra mim" → "para mim"; "Presencial em Apucarana e
  online" → "Presencial e online" (Apucarana já aparece no cabeçalho, no
  rodapé e na seção de atendimento).
- **Travessões removidos de todo o texto visível** (vírgula, dois-pontos,
  ponto médio `·` ou reescrita da frase). O CSS ficou intacto: os traços que
  aparecem como marcadores de lista continuam sendo desenhados pelo
  `content: '—'`, que não é texto do site.
