let csrf = "";
export function setCsrf(value) {
  csrf = value || "";
}
export async function api(path, options = {}) {
  const { body, method = "GET", ...rest } = options;
  const response = await fetch("/api" + path, {
    method,
    credentials: "same-origin",
    ...rest,
    headers: {
      ...(body !== undefined ? { "Content-Type": "application/json" } : {}),
      ...(csrf ? { "X-CSRF-Token": csrf } : {}),
      ...rest.headers,
    },
    ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok)
    throw Object.assign(
      new Error(
        data.error?.message || "Não foi possível conectar. Tente novamente.",
      ),
      { status: response.status, code: data.error?.code },
    );
  return data;
}
export const dateLabel = (value, options = {}) =>
  new Date(value).toLocaleDateString("pt-BR", {
    timeZone: "America/Sao_Paulo",
    day: "2-digit",
    month: "short",
    ...options,
  });
export const timeLabel = (value) =>
  new Date(value).toLocaleTimeString("pt-BR", {
    timeZone: "America/Sao_Paulo",
    hour: "2-digit",
    minute: "2-digit",
  });
export const dayKey = (value) =>
  new Date(value).toLocaleDateString("en-CA", {
    timeZone: "America/Sao_Paulo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  });
export const todayKey = () => dayKey(new Date());
export const addDays = (day, n) => {
  const d = new Date(day + "T12:00:00Z");
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
};
export const money = (cents) =>
  (cents / 100).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
export const statusNames = {
  pending: "Aguardando resposta",
  confirmed: "Confirmado",
  cancelled: "Cancelado",
  completed: "Concluído",
  queued: "Na fila",
  processing: "Enviando",
  sent: "Enviada à Meta",
  failed: "Rejeitada",
  skipped: "Não enviada",
  unknown: "Entrega não confirmada",
};
export const kindNames = {
  confirmation: "Confirmação",
  reminder_24h: "Lembrete · 1 dia antes",
  reminder_2h: "Lembrete · 2 horas antes",
  cancellation: "Cancelamento",
};
